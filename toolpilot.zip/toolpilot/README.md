# ToolPilot – free browser-based tools (Next.js + TypeScript + Tailwind + React Three Fiber)

26 tools, all processed in the visitor's browser. No database, no backend, no paid APIs.

## Run
```bash
npm install
cp .env.example .env.local   # set your domain, email, AdSense id
npm run dev                  # http://localhost:3000
npm run build                # static site in ./out  (deploy anywhere)
```
Deploy `out/` to Cloudflare Pages, Netlify, Vercel or GitHub Pages (all free tiers).

## Rename the site
Edit `SITE.name` in `src/lib/site.ts`. Titles, footer, schema, privacy/terms all follow it.

## Add a tool
1. Add one `t(...)` entry in `src/lib/tools.ts` (name, description, 2 FAQs). The page, SEO metadata, JSON-LD and sitemap entry are generated automatically.
2. Create the component in `src/components/tools/` and register it in `src/components/ToolRunner.tsx`.

## AdSense
Ads are OFF until you set `NEXT_PUBLIC_ADSENSE_CLIENT=ca-pub-XXXX` in `.env.local`. Slots (`<AdSlot slot="..."/>`) reserve space to avoid layout shift. Put your slot ids in `src/app/page.tsx` and `src/app/tools/[slug]/page.tsx`, and add your line to `public/ads.txt`.
AdSense approval usually wants real content, a live domain, and the Privacy/Terms/Contact pages (included). Review the legal pages with a professional before launch.

## SEO included
Per-page title/description/canonical/OpenGraph, WebApplication + FAQPage + Breadcrumb JSON-LD, `sitemap.xml`, `robots.txt`, semantic headings, FAQ on every tool page.
