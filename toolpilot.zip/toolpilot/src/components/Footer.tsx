import Link from "next/link";
import { SITE } from "@/lib/site";
import { CATEGORIES, TOOLS } from "@/lib/tools";
export default function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="text-lg font-extrabold text-slate-900">{SITE.name}</p>
          <p className="mt-2 text-sm text-slate-500">Free tools that run in your browser. Your files never leave your device.</p>
        </div>
        {CATEGORIES.slice(0, 3).map((c) => (
          <div key={c}>
            <p className="text-sm font-semibold text-slate-900">{c}</p>
            <ul className="mt-2 space-y-1 text-sm text-slate-500">
              {TOOLS.filter((t) => t.category === c).slice(0, 5).map((t) => (
                <li key={t.slug}><Link className="hover:text-brand-600" href={`/tools/${t.slug}`}>{t.name}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-100 py-5 text-center text-sm text-slate-500">
        <Link className="mx-2 hover:text-brand-600" href="/about">About</Link>
        <Link className="mx-2 hover:text-brand-600" href="/contact">Contact</Link>
        <Link className="mx-2 hover:text-brand-600" href="/faq">FAQ</Link>
        <Link className="mx-2 hover:text-brand-600" href="/privacy">Privacy Policy</Link>
        <Link className="mx-2 hover:text-brand-600" href="/terms">Terms of Service</Link>
        <p className="mt-2">© {new Date().getFullYear()} {SITE.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}
