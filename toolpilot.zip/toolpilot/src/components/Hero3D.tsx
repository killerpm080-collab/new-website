"use client";
import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
const Scene = dynamic(() => import("./HeroScene"), { ssr: false });

/** Loads the 3D scene only after the page is idle, and never for reduced-motion users (fast mobile LCP). */
export default function Hero3D() {
  const [on, setOn] = useState(false);
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const go = () => setOn(true);
    if ("requestIdleCallback" in window) { const id = requestIdleCallback(go, { timeout: 1500 }); return () => cancelIdleCallback(id); }
    const id = setTimeout(go, 700); return () => clearTimeout(id);
  }, []);
  return <div aria-hidden className="absolute inset-0">{on && <Scene />}</div>;
}
