"use client";
import { lazy, Suspense, type ComponentType } from "react";

const d = (f: () => Promise<{ default: ComponentType }>) => lazy(f);
const named = (f: () => Promise<Record<string, ComponentType>>, n: string) => lazy(() => f().then((m) => ({ default: m[n] })));

const MAP: Record<string, ComponentType> = {
  "image-compressor": d(() => import("./tools/ImageCompressor")),
  "image-resizer": d(() => import("./tools/ImageResizer")),
  "jpg-png-converter": d(() => import("./tools/ImageConverter")),
  "image-cropper": d(() => import("./tools/ImageCropper")),
  "image-upscaler": d(() => import("./tools/ImageUpscaler")),
  "image-to-pdf": d(() => import("./tools/ImageToPdf")),
  "merge-pdf": d(() => import("./tools/MergePdf")),
  "word-counter": named(() => import("./tools/TextStats"), "WordCounter"),
  "character-counter": named(() => import("./tools/TextStats"), "CharCounter"),
  "case-converter": named(() => import("./tools/TextTools"), "CaseConverter"),
  "lorem-ipsum-generator": named(() => import("./tools/TextTools"), "LoremIpsum"),
  "remove-duplicate-lines": named(() => import("./tools/TextTools"), "DedupeLines"),
  "slug-generator": named(() => import("./tools/TextTools"), "SlugGenerator"),
  "percentage-calculator": named(() => import("./tools/Calculators"), "Percentage"),
  "unit-converter": named(() => import("./tools/Calculators"), "UnitConverter"),
  "age-calculator": named(() => import("./tools/Calculators"), "AgeCalculator"),
  "bmi-calculator": named(() => import("./tools/Calculators"), "Bmi"),
  "loan-emi-calculator": named(() => import("./tools/Calculators"), "LoanEmi"),
  "discount-calculator": named(() => import("./tools/Calculators"), "Discount"),
  "date-difference-calculator": named(() => import("./tools/Calculators"), "DateDiff"),
  "qr-code-generator": d(() => import("./tools/QrCode")),
  "color-palette-generator": d(() => import("./tools/ColorPalette")),
  "password-generator": named(() => import("./tools/DevTools"), "PasswordGenerator"),
  "json-formatter": named(() => import("./tools/DevTools"), "JsonFormatter"),
  "base64-encoder-decoder": named(() => import("./tools/DevTools"), "Base64Tool"),
  "timestamp-converter": named(() => import("./tools/DevTools"), "TimestampConverter"),
};
export default function ToolRunner({ slug }: { slug: string }) {
  const C = MAP[slug];
  return C ? <Suspense fallback={<div className="h-40 animate-pulse rounded-2xl bg-slate-100" />}><C /></Suspense> : null;
}
