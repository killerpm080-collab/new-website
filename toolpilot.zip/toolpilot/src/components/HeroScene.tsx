"use client";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import type { Group } from "three";

function Shapes() {
  const g = useRef<Group>(null);
  const width = useThree((s) => s.size.width);
  const pts = useMemo(() => Float32Array.from({ length: 900 }, () => (Math.random() - 0.5) * 18), []);
  const wide = width > 800;
  useFrame((s, d) => {
    const o = g.current;
    if (!o) return;
    o.rotation.y += d * 0.35;
    o.rotation.x += (s.pointer.y * 0.4 - o.rotation.x) * 0.04;
  });
  return (
    <>
      <group ref={g} position={[wide ? 2 : 0, wide ? 0 : 1.4, 0]} scale={wide ? 1 : 0.7}>
        <mesh><icosahedronGeometry args={[2, 1]} /><meshBasicMaterial color="#8b5cf6" wireframe transparent opacity={0.5} /></mesh>
        <mesh><torusKnotGeometry args={[0.8, 0.26, 140, 18]} /><meshNormalMaterial /></mesh>
      </group>
      <points>
        <bufferGeometry><bufferAttribute attach="attributes-position" args={[pts, 3]} /></bufferGeometry>
        <pointsMaterial color="#ec4899" size={0.035} sizeAttenuation />
      </points>
    </>
  );
}
export default function HeroScene() {
  return (
    <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 6.5], fov: 50 }} gl={{ antialias: false, powerPreference: "low-power" }}>
      <Shapes />
    </Canvas>
  );
}
