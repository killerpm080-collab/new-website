import Link from "next/link";
import { SITE } from "@/lib/site";
export default function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="text-lg font-extrabold tracking-tight text-slate-900">
          🧰 {SITE.name.slice(0, 4)}<span className="bg-gradient-to-r from-brand-600 to-pink-500 bg-clip-text text-transparent">{SITE.name.slice(4)}</span>
        </Link>
        <nav className="flex items-center gap-4 text-sm font-medium text-slate-600">
          <Link href="/#tools" className="hover:text-brand-600">Tools</Link>
          <Link href="/faq" className="hover:text-brand-600">FAQ</Link>
          <Link href="/about" className="hidden hover:text-brand-600 sm:block">About</Link>
          <Link href="/contact" className="hidden hover:text-brand-600 sm:block">Contact</Link>
        </nav>
      </div>
    </header>
  );
}
