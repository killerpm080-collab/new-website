export default function FaqList({ items }: { items: [string, string][] }) {
  return (
    <div className="divide-y divide-slate-200 rounded-2xl border border-slate-200 bg-white">
      {items.map(([q, a]) => (
        <details key={q} className="group p-4 sm:px-6">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold text-slate-900">
            {q}<span className="text-brand-600 transition group-open:rotate-45">+</span>
          </summary>
          <p className="mt-2 leading-7 text-slate-600">{a}</p>
        </details>
      ))}
    </div>
  );
}
export const faqJsonLd = (items: [string, string][]) => ({
  "@context": "https://schema.org", "@type": "FAQPage",
  mainEntity: items.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })),
});
