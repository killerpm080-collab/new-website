"use client";
import { useState } from "react";
import { Field, Stat } from "../ui";

function useText() { return useState(""); }
const words = (t: string) => (t.trim().match(/\S+/g) || []).length;

export function WordCounter() {
  const [t, setT] = useText();
  const w = words(t), sentences = (t.match(/[^.!?]+[.!?]+/g) || []).length, paras = t.split(/\n\s*\n/).filter((s) => s.trim()).length;
  return (
    <div className="space-y-4">
      <Field label="Your text"><textarea className="input" rows={9} placeholder="Type or paste your text here…" value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Stat k="Words" v={w} /><Stat k="Characters" v={[...t].length} /><Stat k="Sentences" v={sentences} />
        <Stat k="Paragraphs" v={paras} /><Stat k="Reading time" v={`${Math.ceil(w / 230)} min`} /><Stat k="Speaking time" v={`${Math.ceil(w / 130)} min`} />
      </div>
    </div>
  );
}
export function CharCounter() {
  const [t, setT] = useText();
  const n = [...t].length;
  const limits: [string, number][] = [["X / Twitter post", 280], ["Instagram bio", 150], ["Meta description", 160], ["SMS segment", 160], ["Meta title", 60]];
  return (
    <div className="space-y-4">
      <Field label="Your text"><textarea className="input" rows={9} placeholder="Type or paste your text here…" value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat k="Characters" v={n} /><Stat k="Without spaces" v={t.replace(/\s/g, "").length} /><Stat k="Words" v={words(t)} /><Stat k="Lines" v={t ? t.split("\n").length : 0} />
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {limits.map(([k, max]) => (
          <div key={k} className="rounded-xl border border-slate-200 p-3 text-sm">
            <div className="flex justify-between"><span>{k}</span><span className={n > max ? "font-bold text-red-600" : "text-slate-500"}>{n} / {max}</span></div>
            <div className="mt-2 h-1.5 rounded bg-slate-100"><div className={`h-full rounded ${n > max ? "bg-red-500" : "bg-brand-500"}`} style={{ width: `${Math.min(100, (n / max) * 100)}%` }} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}
