"use client";
import { useState } from "react";
import { PDFDocument } from "pdf-lib";
import { Dropzone, Err, Result, kb } from "../ui";

export default function MergePdf() {
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState("");
  const [out, setOut] = useState<Blob | null>(null);
  const move = (i: number, d: number) => setFiles((f) => { const n = [...f], j = i + d; if (j < 0 || j >= n.length) return f; [n[i], n[j]] = [n[j], n[i]]; return n; });
  const merge = async () => {
    if (files.length < 2) return setMsg("Add at least two PDF files.");
    setBusy(true); setMsg("");
    try {
      const doc = await PDFDocument.create();
      for (const f of files) {
        const src = await PDFDocument.load(await f.arrayBuffer());
        (await doc.copyPages(src, src.getPageIndices())).forEach((p) => doc.addPage(p));
      }
      setOut(new Blob([(await doc.save()) as unknown as BlobPart], { type: "application/pdf" }));
    } catch { setMsg("A file could not be read. It may be encrypted or damaged."); }
    setBusy(false);
  };
  return (
    <div className="space-y-4">
      <Dropzone multiple accept="application/pdf" onFiles={(f) => { setFiles((o) => [...o, ...f.filter((x) => x.type === "application/pdf")]); setOut(null); }} hint="Add two or more PDF files" />
      <Err msg={msg} />
      {files.length > 0 && (
        <>
          <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
            {files.map((f, i) => (
              <li key={i} className="flex items-center gap-2 p-2 text-sm">
                <span className="flex-1 truncate">{i + 1}. {f.name} <span className="text-slate-400">({kb(f.size)})</span></span>
                <button className="btn-ghost !px-2 !py-1" onClick={() => move(i, -1)}>↑</button>
                <button className="btn-ghost !px-2 !py-1" onClick={() => move(i, 1)}>↓</button>
                <button className="btn-ghost !px-2 !py-1" onClick={() => setFiles((o) => o.filter((_, j) => j !== i))}>✕</button>
              </li>
            ))}
          </ul>
          <button className="btn" onClick={merge} disabled={busy}>{busy ? "Merging…" : "Merge PDFs"}</button>
        </>
      )}
      <Result blob={out} name="merged.pdf" info={out ? kb(out.size) : undefined} />
    </div>
  );
}
