"use client";
import { useState } from "react";
import { Field, Stat } from "../ui";

const num = (v: string) => (v.trim() === "" ? NaN : parseFloat(v));
const fmt = (n: number, d = 2) => (isFinite(n) ? n.toLocaleString(undefined, { maximumFractionDigits: d }) : "—");
function Num({ label, v, set, ph }: { label: string; v: string; set: (s: string) => void; ph?: string }) {
  return <Field label={label}><input className="input" type="number" inputMode="decimal" placeholder={ph} value={v} onChange={(e) => set(e.target.value)} /></Field>;
}
const Row = ({ children }: { children: React.ReactNode }) => <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 text-slate-700">{children}</div>;

export function Percentage() {
  const [a, setA] = useState(""), [b, setB] = useState(""), [c, setC] = useState(""), [d, setD] = useState(""), [e, setE] = useState(""), [f, setF] = useState("");
  const inp = (v: string, s: (x: string) => void) => <input className="input !w-28" type="number" value={v} onChange={(x) => s(x.target.value)} />;
  const out = (s: string) => <b className="text-lg text-brand-600">{s}</b>;
  return (
    <div className="space-y-3">
      <Row>What is {inp(a, setA)} % of {inp(b, setB)} = {out(fmt((num(a) / 100) * num(b), 4))}</Row>
      <Row>{inp(c, setC)} is what % of {inp(d, setD)} = {out(isFinite(num(c) / num(d)) ? fmt((num(c) / num(d)) * 100, 4) + "%" : "—")}</Row>
      <Row>% change from {inp(e, setE)} to {inp(f, setF)} = {out(isFinite((num(f) - num(e)) / Math.abs(num(e))) ? fmt(((num(f) - num(e)) / Math.abs(num(e))) * 100, 4) + "%" : "—")}</Row>
    </div>
  );
}
const U: Record<string, Record<string, number>> = {
  Length: { m: 1, km: 1e3, cm: 0.01, mm: 0.001, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254 },
  Weight: { kg: 1, g: 0.001, mg: 1e-6, lb: 0.45359237, oz: 0.028349523 },
  Volume: { L: 1, mL: 0.001, gal: 3.785411784, qt: 0.946352946, cup: 0.2365882365, "fl oz": 0.0295735296 },
  Speed: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704, knot: 0.514444 },
  Area: { "m²": 1, "km²": 1e6, ha: 1e4, acre: 4046.8564224, "ft²": 0.09290304 },
  Data: { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 },
  Time: { s: 1, min: 60, h: 3600, day: 86400, week: 604800 },
  Temperature: { C: 1, F: 1, K: 1 },
};
export function UnitConverter() {
  const [cat, setCat] = useState("Length"), [v, setV] = useState("1"), [from, setFrom] = useState("m"), [to, setTo] = useState("ft");
  const units = Object.keys(U[cat]);
  const change = (c: string) => { setCat(c); const k = Object.keys(U[c]); setFrom(k[0]); setTo(k[1]); };
  const x = num(v);
  let r: number;
  if (cat === "Temperature") { const C = from === "C" ? x : from === "F" ? ((x - 32) * 5) / 9 : x - 273.15; r = to === "C" ? C : to === "F" ? (C * 9) / 5 + 32 : C + 273.15; }
  else r = (x * U[cat][from]) / U[cat][to];
  const Sel = ({ val, set }: { val: string; set: (s: string) => void }) => <select className="input" value={val} onChange={(e) => set(e.target.value)}>{units.map((u) => <option key={u}>{u}</option>)}</select>;
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Category"><select className="input" value={cat} onChange={(e) => change(e.target.value)}>{Object.keys(U).map((c) => <option key={c}>{c}</option>)}</select></Field>
        <Num label="Value" v={v} set={setV} />
        <Field label="From"><Sel val={from} set={setFrom} /></Field>
        <Field label="To"><Sel val={to} set={setTo} /></Field>
      </div>
      <Stat k="Result" v={isFinite(r) ? `${+r.toPrecision(10)} ${to}` : "—"} />
    </div>
  );
}
export function AgeCalculator() {
  const [dob, setDob] = useState("");
  let body = null;
  if (dob) {
    const d = new Date(dob + "T00:00:00"), t = new Date(), today = new Date(t.getFullYear(), t.getMonth(), t.getDate());
    if (d > today) body = <p className="text-red-600">Date of birth is in the future.</p>;
    else {
      let y = today.getFullYear() - d.getFullYear(), m = today.getMonth() - d.getMonth(), dd = today.getDate() - d.getDate();
      if (dd < 0) { m--; dd += new Date(today.getFullYear(), today.getMonth(), 0).getDate(); }
      if (m < 0) { y--; m += 12; }
      const nb = new Date(today.getFullYear(), d.getMonth(), d.getDate());
      if (nb < today) nb.setFullYear(nb.getFullYear() + 1);
      body = (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Stat k="Your age" v={`${y}y ${m}m ${dd}d`} /><Stat k="Days lived" v={fmt(Math.floor((+today - +d) / 864e5), 0)} /><Stat k="Next birthday in" v={`${Math.round((+nb - +today) / 864e5)} days`} />
        </div>
      );
    }
  }
  return <div className="space-y-4"><Field label="Date of birth"><input className="input max-w-xs" type="date" value={dob} onChange={(e) => setDob(e.target.value)} /></Field>{body}</div>;
}
export function Bmi() {
  const [metric, setMetric] = useState(true), [w, setW] = useState(""), [h, setH] = useState("");
  const bmi = metric ? num(w) / Math.pow(num(h) / 100, 2) : (703 * num(w)) / Math.pow(num(h), 2);
  const cat = bmi < 18.5 ? "Underweight" : bmi < 25 ? "Healthy weight" : bmi < 30 ? "Overweight" : "Obesity";
  return (
    <div className="space-y-4">
      <div className="flex gap-2"><button className={metric ? "btn" : "btn-ghost"} onClick={() => setMetric(true)}>Metric (kg, cm)</button><button className={!metric ? "btn" : "btn-ghost"} onClick={() => setMetric(false)}>Imperial (lb, in)</button></div>
      <div className="grid gap-4 sm:grid-cols-2"><Num label={metric ? "Weight (kg)" : "Weight (lb)"} v={w} set={setW} /><Num label={metric ? "Height (cm)" : "Height (inches)"} v={h} set={setH} /></div>
      {isFinite(bmi) && bmi > 0 && <div className="grid grid-cols-2 gap-3"><Stat k="Your BMI" v={bmi.toFixed(1)} /><Stat k="Category" v={cat} /></div>}
      <p className="text-xs text-slate-500">BMI is a general screening number, not a medical diagnosis.</p>
    </div>
  );
}
export function LoanEmi() {
  const [p, setP] = useState(""), [r, setR] = useState(""), [y, setY] = useState("");
  const P = num(p), n = num(y) * 12, i = num(r) / 12 / 100;
  const emi = i === 0 ? P / n : (P * i * Math.pow(1 + i, n)) / (Math.pow(1 + i, n) - 1);
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3"><Num label="Loan amount" v={p} set={setP} ph="500000" /><Num label="Annual interest rate (%)" v={r} set={setR} ph="9.5" /><Num label="Term (years)" v={y} set={setY} ph="5" /></div>
      {isFinite(emi) && emi > 0 && <div className="grid grid-cols-1 gap-3 sm:grid-cols-3"><Stat k="Monthly EMI" v={fmt(emi)} /><Stat k="Total interest" v={fmt(emi * n - P)} /><Stat k="Total payment" v={fmt(emi * n)} /></div>}
    </div>
  );
}
export function Discount() {
  const [p, setP] = useState(""), [d, setD] = useState(""), [t, setT] = useState("");
  const P = num(p), disc = isFinite(num(d)) ? num(d) : 0, tax = isFinite(num(t)) ? num(t) : 0;
  const after = P * (1 - disc / 100), taxAmt = (after * tax) / 100;
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3"><Num label="Original price" v={p} set={setP} /><Num label="Discount (%)" v={d} set={setD} /><Num label="Tax / GST (%)" v={t} set={setT} /></div>
      {isFinite(P) && <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><Stat k="You save" v={fmt(P - after)} /><Stat k="Price after discount" v={fmt(after)} /><Stat k="Tax" v={fmt(taxAmt)} /><Stat k="Final price" v={fmt(after + taxAmt)} /></div>}
    </div>
  );
}
export function DateDiff() {
  const [a, setA] = useState(""), [b, setB] = useState("");
  let body = null;
  if (a && b) {
    let s = new Date(a + "T00:00:00"), e = new Date(b + "T00:00:00");
    if (s > e) [s, e] = [e, s];
    const days = Math.round((+e - +s) / 864e5);
    let y = e.getFullYear() - s.getFullYear(), m = e.getMonth() - s.getMonth(), dd = e.getDate() - s.getDate();
    if (dd < 0) { m--; dd += new Date(e.getFullYear(), e.getMonth(), 0).getDate(); }
    if (m < 0) { y--; m += 12; }
    let wd = 0; for (let i = 0; i < days; i++) { const g = new Date(+s + i * 864e5).getDay(); if (g !== 0 && g !== 6) wd++; }
    body = <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><Stat k="Total days" v={fmt(days, 0)} /><Stat k="Weeks" v={`${Math.floor(days / 7)}w ${days % 7}d`} /><Stat k="Y / M / D" v={`${y}y ${m}m ${dd}d`} /><Stat k="Weekdays" v={fmt(wd, 0)} /></div>;
  }
  return <div className="space-y-4"><div className="grid gap-4 sm:grid-cols-2"><Field label="Start date"><input className="input" type="date" value={a} onChange={(e) => setA(e.target.value)} /></Field><Field label="End date"><input className="input" type="date" value={b} onChange={(e) => setB(e.target.value)} /></Field></div>{body}</div>;
}
