"use client";
import { useEffect, useState } from "react";
import { Dropzone, Err, Field, Result, useImageSource, makeCanvas, toBlob, kb, baseName, EXT } from "../ui";

export default function ImageConverter() {
  const { file, img, set, error } = useImageSource();
  const [type, setType] = useState("image/png");
  const [out, setOut] = useState<Blob | null>(null);
  useEffect(() => {
    if (!img) return;
    let live = true;
    (async () => {
      const c = makeCanvas(img.width, img.height), x = c.getContext("2d")!;
      if (type === "image/jpeg") { x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); }
      x.drawImage(img, 0, 0);
      const b = await toBlob(c, type, 0.95);
      if (live) setOut(b);
    })();
    return () => { live = false; };
  }, [img, type]);
  return (
    <div className="space-y-4">
      <Dropzone onFiles={set} hint="JPG, PNG, WebP, GIF, BMP" />
      <Err msg={error} />
      <Field label="Convert to">
        <select className="input max-w-xs" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="image/png">PNG</option><option value="image/jpeg">JPG</option><option value="image/webp">WebP</option>
        </select>
      </Field>
      <Result blob={out} name={file ? `${baseName(file)}.${EXT[type]}` : ""} info={file && out ? `${kb(file.size)} → ${kb(out.size)}` : undefined} />
    </div>
  );
}
