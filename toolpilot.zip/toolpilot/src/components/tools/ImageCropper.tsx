"use client";
import { useEffect, useRef, useState } from "react";
import { Dropzone, Err, Result, useImageSource, makeCanvas, toBlob, kb, baseName } from "../ui";

type Rect = { x: number; y: number; w: number; h: number };
export default function ImageCropper() {
  const { file, img, set, error } = useImageSource();
  const cv = useRef<HTMLCanvasElement>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const [rect, setRect] = useState<Rect | null>(null);
  const [out, setOut] = useState<Blob | null>(null);
  const scale = img ? Math.min(1, 760 / img.width) : 1;

  useEffect(() => {
    const c = cv.current;
    if (!c || !img) return;
    c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
    setRect(null); setOut(null);
  }, [img, scale]);
  useEffect(() => {
    const c = cv.current;
    if (!c || !img) return;
    const x = c.getContext("2d")!;
    x.drawImage(img, 0, 0, c.width, c.height);
    if (rect) {
      x.fillStyle = "rgba(0,0,0,.55)"; x.fillRect(0, 0, c.width, c.height);
      x.drawImage(img, rect.x / scale, rect.y / scale, rect.w / scale, rect.h / scale, rect.x, rect.y, rect.w, rect.h);
      x.strokeStyle = "#fff"; x.lineWidth = 2; x.strokeRect(rect.x, rect.y, rect.w, rect.h);
    }
  }, [img, rect, scale]);

  const pt = (e: React.PointerEvent) => {
    const c = cv.current!, b = c.getBoundingClientRect();
    return { x: Math.max(0, Math.min(c.width, ((e.clientX - b.left) * c.width) / b.width)), y: Math.max(0, Math.min(c.height, ((e.clientY - b.top) * c.height) / b.height)) };
  };
  const crop = async () => {
    if (!img || !rect || rect.w < 4 || rect.h < 4) return;
    const o = makeCanvas(Math.round(rect.w / scale), Math.round(rect.h / scale));
    o.getContext("2d")!.drawImage(img, rect.x / scale, rect.y / scale, rect.w / scale, rect.h / scale, 0, 0, o.width, o.height);
    setOut(await toBlob(o, "image/png"));
  };
  return (
    <div className="space-y-4">
      <Dropzone onFiles={set} />
      <Err msg={error} />
      {img && (
        <>
          <p className="text-sm text-slate-500">{rect ? `${Math.round(rect.w / scale)}×${Math.round(rect.h / scale)}px selected` : "Drag on the image to select the area to keep."}</p>
          <canvas ref={cv} className="max-w-full cursor-crosshair touch-none rounded-xl"
            onPointerDown={(e) => { start.current = pt(e); e.currentTarget.setPointerCapture(e.pointerId); }}
            onPointerUp={() => (start.current = null)}
            onPointerMove={(e) => { const s = start.current; if (!s) return; const p = pt(e); setRect({ x: Math.min(s.x, p.x), y: Math.min(s.y, p.y), w: Math.abs(p.x - s.x), h: Math.abs(p.y - s.y) }); }} />
          <button className="btn" onClick={crop} disabled={!rect}>Crop selection</button>
        </>
      )}
      <Result blob={out} name={file ? `${baseName(file)}-cropped.png` : ""} info={out ? kb(out.size) : undefined} />
    </div>
  );
}
