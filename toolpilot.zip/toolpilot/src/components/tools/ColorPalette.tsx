"use client";
import { useEffect, useState } from "react";
import { Dropzone, copy, loadImage, makeCanvas } from "../ui";

const hex = (r: number, g: number, b: number) => "#" + [r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("");
function hsl(h: number, s: number, l: number) {
  h %= 360; s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l), f = (n: number) => { const k = (n + h / 30) % 12; return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))); };
  return hex(f(0), f(8), f(4));
}
const random = () => { const h = Math.random() * 360; return ([[0, 70, 55], [30, 65, 70], [180, 55, 45], [210, 60, 62], [330, 50, 35]] as const).map(([o, s, l]) => hsl(h + o, s, l)); };

export default function ColorPalette() {
  const [colors, setColors] = useState<string[]>([]);
  const [copied, setCopied] = useState("");
  useEffect(() => setColors(random()), []);
  const fromImage = async (fs: File[]) => {
    const f = fs[0]; if (!f || !f.type.startsWith("image/")) return;
    const i = await loadImage(f), c = makeCanvas(64, 64), x = c.getContext("2d")!;
    x.drawImage(i, 0, 0, 64, 64);
    const d = x.getImageData(0, 0, 64, 64).data, m: Record<string, number> = {};
    for (let p = 0; p < d.length; p += 4) { if (d[p + 3] < 128) continue; const k = [d[p] >> 5, d[p + 1] >> 5, d[p + 2] >> 5].join(); m[k] = (m[k] || 0) + 1; }
    setColors(Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k]) => { const [r, g, b] = k.split(",").map((v) => +v * 32 + 16); return hex(r, g, b); }));
  };
  return (
    <div className="space-y-4">
      <button className="btn" onClick={() => setColors(random())}>🎲 Generate random palette</button>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {colors.map((c) => (
          <button key={c} onClick={() => { copy(c); setCopied(c); setTimeout(() => setCopied(""), 900); }} style={{ background: c }} className="flex h-28 items-end rounded-2xl p-2 transition hover:scale-[1.03]">
            <span className="rounded-lg bg-black/60 px-2 py-0.5 font-mono text-xs font-semibold text-white">{copied === c ? "Copied!" : c}</span>
          </button>
        ))}
      </div>
      <p className="text-sm text-slate-500">Click a color to copy its HEX code. Or extract colors from a picture:</p>
      <Dropzone onFiles={fromImage} hint="Upload an image to extract its main colors" />
    </div>
  );
}
