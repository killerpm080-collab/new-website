"use client";
import { useState } from "react";
import { Field, copy } from "../ui";

export function CaseConverter() {
  const [t, setT] = useState("");
  const m: Record<string, (s: string) => string> = {
    UPPERCASE: (s) => s.toUpperCase(),
    lowercase: (s) => s.toLowerCase(),
    "Title Case": (s) => s.toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase()),
    "Sentence case": (s) => s.toLowerCase().replace(/(^\s*|[.!?]\s+)(\S)/g, (_, a, b) => a + b.toUpperCase()),
  };
  return (
    <div className="space-y-4">
      <Field label="Your text"><textarea className="input" rows={8} value={t} onChange={(e) => setT(e.target.value)} placeholder="Paste text, then pick a case…" /></Field>
      <div className="flex flex-wrap gap-2">
        {Object.keys(m).map((k) => <button key={k} className="btn-ghost" onClick={() => setT(m[k](t))}>{k}</button>)}
        <button className="btn" onClick={() => copy(t)}>Copy text</button>
      </div>
    </div>
  );
}
const WORDS = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure in reprehenderit voluptate velit esse cillum fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt culpa qui officia deserunt mollit anim id est laborum".split(" ");
export function LoremIpsum() {
  const [n, setN] = useState(3), [out, setOut] = useState("");
  const gen = () => {
    const sentence = () => { const len = 8 + Math.floor(Math.random() * 10), w = Array.from({ length: len }, () => WORDS[Math.floor(Math.random() * WORDS.length)]); const s = w.join(" "); return s[0].toUpperCase() + s.slice(1) + "."; };
    setOut(Array.from({ length: n }, (_, i) => (i === 0 ? "Lorem ipsum dolor sit amet. " : "") + Array.from({ length: 4 + Math.floor(Math.random() * 3) }, sentence).join(" ")).join("\n\n"));
  };
  return (
    <div className="space-y-4">
      <div className="flex items-end gap-3">
        <Field label="Paragraphs"><input className="input w-28" type="number" min={1} max={30} value={n} onChange={(e) => setN(Math.max(1, Math.min(30, +e.target.value)))} /></Field>
        <button className="btn" onClick={gen}>Generate</button>
        {out && <button className="btn-ghost" onClick={() => copy(out)}>Copy</button>}
      </div>
      {out && <textarea readOnly className="input" rows={10} value={out} />}
    </div>
  );
}
export function DedupeLines() {
  const [t, setT] = useState(""), [ic, setIc] = useState(false), [tr, setTr] = useState(true), [so, setSo] = useState(false), [ek, setEk] = useState(true);
  let lines = t ? t.split("\n") : [];
  const before = lines.length;
  if (tr) lines = lines.map((l) => l.trim());
  if (ek) lines = lines.filter((l) => l !== "");
  const seen = new Set<string>();
  lines = lines.filter((l) => { const k = ic ? l.toLowerCase() : l; if (seen.has(k)) return false; seen.add(k); return true; });
  if (so) lines = [...lines].sort((a, b) => a.localeCompare(b));
  const out = lines.join("\n");
  const Opt = ({ l, v, s }: { l: string; v: boolean; s: (b: boolean) => void }) => <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" checked={v} onChange={(e) => s(e.target.checked)} />{l}</label>;
  return (
    <div className="space-y-4">
      <Field label="Paste your list (one item per line)"><textarea className="input" rows={8} value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <div className="flex flex-wrap gap-4"><Opt l="Ignore case" v={ic} s={setIc} /><Opt l="Trim spaces" v={tr} s={setTr} /><Opt l="Remove empty lines" v={ek} s={setEk} /><Opt l="Sort A–Z" v={so} s={setSo} /></div>
      {t && <p className="text-sm text-slate-500">{before} lines → {lines.length} unique lines ({before - lines.length} removed)</p>}
      {t && <><textarea readOnly className="input" rows={8} value={out} /><button className="btn" onClick={() => copy(out)}>Copy result</button></>}
    </div>
  );
}
export function SlugGenerator() {
  const [t, setT] = useState("");
  const slug = t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return (
    <div className="space-y-4">
      <Field label="Title or phrase"><input className="input" value={t} onChange={(e) => setT(e.target.value)} placeholder="10 Best Tips for Faster Websites!" /></Field>
      {slug && <div className="flex items-center gap-2 rounded-xl bg-slate-50 p-3"><code className="flex-1 break-all text-sm">{slug}</code><button className="btn-ghost" onClick={() => copy(slug)}>Copy</button></div>}
    </div>
  );
}
