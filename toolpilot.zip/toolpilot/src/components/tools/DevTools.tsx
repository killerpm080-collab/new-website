"use client";
import { useEffect, useState } from "react";
import { Err, Field, Stat, copy } from "../ui";

export function PasswordGenerator() {
  const [len, setLen] = useState(16), [nums, setNums] = useState(true), [syms, setSyms] = useState(true), [pw, setPw] = useState("");
  const gen = () => {
    let s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (nums) s += "0123456789"; if (syms) s += "!@#$%^&*()-_=+[]{}?";
    const a = crypto.getRandomValues(new Uint32Array(len));
    setPw([...a].map((v) => s[v % s.length]).join(""));
  };
  useEffect(gen, [len, nums, syms]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="space-y-4">
      <div className="break-all rounded-xl bg-slate-900 p-4 font-mono text-lg text-green-300">{pw}</div>
      <div className="grid items-end gap-4 sm:grid-cols-3">
        <Field label={`Length: ${len}`}><input type="range" min={8} max={64} value={len} onChange={(e) => setLen(+e.target.value)} className="w-full" /></Field>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={nums} onChange={(e) => setNums(e.target.checked)} />Numbers</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={syms} onChange={(e) => setSyms(e.target.checked)} />Symbols</label>
      </div>
      <div className="flex gap-2"><button className="btn" onClick={gen}>Generate new</button><button className="btn-ghost" onClick={() => copy(pw)}>Copy</button></div>
    </div>
  );
}
export function JsonFormatter() {
  const [t, setT] = useState(""), [out, setOut] = useState(""), [err, setErr] = useState(""), [ind, setInd] = useState(2);
  const run = (min: boolean) => { try { const o = JSON.parse(t); setOut(JSON.stringify(o, null, min ? 0 : ind)); setErr(""); } catch (e) { setErr("Invalid JSON: " + (e as Error).message); setOut(""); } };
  return (
    <div className="space-y-4">
      <Field label="Paste JSON"><textarea className="input font-mono" rows={8} value={t} onChange={(e) => setT(e.target.value)} placeholder='{"name":"value"}' /></Field>
      <div className="flex flex-wrap items-center gap-2">
        <button className="btn" onClick={() => run(false)}>Format</button><button className="btn-ghost" onClick={() => run(true)}>Minify</button>
        <select className="input !w-auto" value={ind} onChange={(e) => setInd(+e.target.value)}><option value={2}>2 spaces</option><option value={4}>4 spaces</option></select>
        {out && <button className="btn-ghost" onClick={() => copy(out)}>Copy</button>}
      </div>
      <Err msg={err} />
      {out && <textarea readOnly className="input font-mono" rows={10} value={out} />}
    </div>
  );
}
export function Base64Tool() {
  const [t, setT] = useState(""), [enc, setEnc] = useState(true);
  let out = "", err = "";
  try {
    if (enc) { const b = new TextEncoder().encode(t); let s = ""; b.forEach((c) => (s += String.fromCharCode(c))); out = btoa(s); }
    else if (t.trim()) { const s = atob(t.trim()); out = new TextDecoder().decode(Uint8Array.from(s, (c) => c.charCodeAt(0))); }
  } catch { err = "This is not valid Base64."; }
  return (
    <div className="space-y-4">
      <div className="flex gap-2"><button className={enc ? "btn" : "btn-ghost"} onClick={() => setEnc(true)}>Encode</button><button className={!enc ? "btn" : "btn-ghost"} onClick={() => setEnc(false)}>Decode</button></div>
      <Field label={enc ? "Text" : "Base64"}><textarea className="input" rows={6} value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <Err msg={err} />
      {out && <><textarea readOnly className="input" rows={6} value={out} /><button className="btn" onClick={() => copy(out)}>Copy result</button></>}
    </div>
  );
}
export function TimestampConverter() {
  const [ts, setTs] = useState(""), [dt, setDt] = useState("");
  useEffect(() => setTs(String(Math.floor(Date.now() / 1000))), []);
  const n = parseFloat(ts), ms = n > 1e11 ? n : n * 1000, d = new Date(ms), ok = ts !== "" && isFinite(ms) && !isNaN(d.getTime());
  const fromDate = dt ? Math.floor(new Date(dt).getTime() / 1000) : NaN;
  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <Field label="Unix timestamp (seconds or milliseconds)"><input className="input" value={ts} onChange={(e) => setTs(e.target.value)} /></Field>
        <button className="btn-ghost" onClick={() => setTs(String(Math.floor(Date.now() / 1000)))}>Use current time</button>
        {ok && <div className="grid gap-3 sm:grid-cols-2"><Stat k="Local time" v={<span className="text-base">{d.toLocaleString()}</span>} /><Stat k="UTC" v={<span className="text-base">{d.toUTCString()}</span>} /></div>}
      </div>
      <div className="space-y-3">
        <Field label="Date and time to timestamp"><input className="input max-w-xs" type="datetime-local" value={dt} onChange={(e) => setDt(e.target.value)} /></Field>
        {isFinite(fromDate) && <Stat k="Unix timestamp (seconds)" v={fromDate} />}
      </div>
    </div>
  );
}
