"use client";
import { useState } from "react";
import { PDFDocument } from "pdf-lib";
import { Dropzone, Err, Result, loadImage, makeCanvas, toBlob, kb } from "../ui";

export default function ImageToPdf() {
  const [files, setFiles] = useState<File[]>([]);
  const [a4, setA4] = useState(true), [busy, setBusy] = useState(false), [msg, setMsg] = useState("");
  const [out, setOut] = useState<Blob | null>(null);
  const move = (i: number, d: number) => setFiles((f) => { const n = [...f], j = i + d; if (j < 0 || j >= n.length) return f; [n[i], n[j]] = [n[j], n[i]]; return n; });
  const build = async () => {
    if (!files.length) return;
    setBusy(true); setMsg("");
    try {
      const doc = await PDFDocument.create();
      for (const f of files) {
        let emb;
        if (f.type === "image/jpeg") emb = await doc.embedJpg(new Uint8Array(await f.arrayBuffer()));
        else if (f.type === "image/png") emb = await doc.embedPng(new Uint8Array(await f.arrayBuffer()));
        else { const im = await loadImage(f), c = makeCanvas(im.width, im.height); c.getContext("2d")!.drawImage(im, 0, 0); emb = await doc.embedPng(new Uint8Array(await (await toBlob(c, "image/png")).arrayBuffer())); }
        if (a4) {
          const W = 595.28, H = 841.89, m = 24, s = Math.min((W - 2 * m) / emb.width, (H - 2 * m) / emb.height), p = doc.addPage([W, H]);
          p.drawImage(emb, { x: (W - emb.width * s) / 2, y: (H - emb.height * s) / 2, width: emb.width * s, height: emb.height * s });
        } else doc.addPage([emb.width, emb.height]).drawImage(emb, { x: 0, y: 0, width: emb.width, height: emb.height });
      }
      setOut(new Blob([(await doc.save()) as unknown as BlobPart], { type: "application/pdf" }));
    } catch { setMsg("One of the images could not be added. Try JPG or PNG files."); }
    setBusy(false);
  };
  return (
    <div className="space-y-4">
      <Dropzone multiple onFiles={(f) => { setFiles((o) => [...o, ...f.filter((x) => x.type.startsWith("image/"))]); setOut(null); }} hint="Add one or more images. Each becomes a PDF page." />
      <Err msg={msg} />
      {files.length > 0 && (
        <>
          <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
            {files.map((f, i) => (
              <li key={i} className="flex items-center gap-2 p-2 text-sm">
                <span className="flex-1 truncate">{i + 1}. {f.name} <span className="text-slate-400">({kb(f.size)})</span></span>
                <button className="btn-ghost !px-2 !py-1" onClick={() => move(i, -1)}>↑</button>
                <button className="btn-ghost !px-2 !py-1" onClick={() => move(i, 1)}>↓</button>
                <button className="btn-ghost !px-2 !py-1" onClick={() => setFiles((o) => o.filter((_, j) => j !== i))}>✕</button>
              </li>
            ))}
          </ul>
          <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" checked={a4} onChange={(e) => setA4(e.target.checked)} /> Fit each image on an A4 page (uncheck to keep original size)</label>
          <button className="btn" onClick={build} disabled={busy}>{busy ? "Creating PDF…" : "Create PDF"}</button>
        </>
      )}
      <Result blob={out} name="images.pdf" info={out ? `${files.length} page(s) · ${kb(out.size)}` : undefined} />
    </div>
  );
}
