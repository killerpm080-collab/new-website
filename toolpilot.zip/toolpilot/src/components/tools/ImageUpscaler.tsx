"use client";
import { useState } from "react";
import { Dropzone, Err, Field, Result, useImageSource, makeCanvas, toBlob, kb, baseName } from "../ui";

function sharpen(c: HTMLCanvasElement) {
  const x = c.getContext("2d")!, W = c.width, H = c.height, d = x.getImageData(0, 0, W, H), s = d.data, o = new Uint8ClampedArray(s);
  for (let y = 1; y < H - 1; y++) for (let i = 1; i < W - 1; i++) {
    const p = (y * W + i) * 4;
    for (let k = 0; k < 3; k++) o[p + k] = s[p + k] * 0.4 + (5 * s[p + k] - s[p + k - 4] - s[p + k + 4] - s[p + k - W * 4] - s[p + k + W * 4]) * 0.6;
  }
  d.data.set(o); x.putImageData(d, 0, 0);
}
export default function ImageUpscaler() {
  const { file, img, set, error } = useImageSource();
  const [k, setK] = useState(2), [sh, setSh] = useState(true), [busy, setBusy] = useState(false), [msg, setMsg] = useState("");
  const [out, setOut] = useState<Blob | null>(null);
  const run = async () => {
    if (!img) return;
    const W = img.width * k, H = img.height * k;
    if (W * H > 4e7) return setMsg("Result would exceed 40 megapixels. Choose a smaller scale or image.");
    setMsg(""); setBusy(true);
    await new Promise((r) => setTimeout(r, 30));
    const c = makeCanvas(W, H), x = c.getContext("2d")!;
    x.imageSmoothingQuality = "high"; x.drawImage(img, 0, 0, W, H);
    if (sh) sharpen(c);
    setOut(await toBlob(c, "image/png")); setBusy(false);
  };
  return (
    <div className="space-y-4">
      <Dropzone onFiles={set} />
      <Err msg={error || msg} />
      {img && (
        <>
          <div className="grid items-end gap-4 sm:grid-cols-3">
            <Field label="Scale"><select className="input" value={k} onChange={(e) => setK(+e.target.value)}><option value={2}>2×</option><option value={3}>3×</option><option value={4}>4×</option></select></Field>
            <label className="flex items-center gap-2 pb-2 text-sm text-slate-600"><input type="checkbox" checked={sh} onChange={(e) => setSh(e.target.checked)} /> Sharpen</label>
            <button className="btn" onClick={run} disabled={busy}>{busy ? "Working…" : "Upscale image"}</button>
          </div>
          <p className="text-sm text-slate-500">{img.width}×{img.height}px → {img.width * k}×{img.height * k}px</p>
        </>
      )}
      <Result blob={out} name={file ? `${baseName(file)}-${k}x.png` : ""} info={out ? kb(out.size) : undefined} />
    </div>
  );
}
