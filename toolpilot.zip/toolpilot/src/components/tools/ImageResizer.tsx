"use client";
import { useEffect, useState } from "react";
import { Dropzone, Err, Field, Result, useImageSource, makeCanvas, toBlob, kb, baseName, EXT } from "../ui";

export default function ImageResizer() {
  const { file, img, set, error } = useImageSource();
  const [w, setW] = useState(0), [h, setH] = useState(0), [lock, setLock] = useState(true);
  const [out, setOut] = useState<Blob | null>(null), [msg, setMsg] = useState("");
  useEffect(() => { if (img) { setW(img.width); setH(img.height); setOut(null); } }, [img]);
  const onW = (v: number) => { setW(v); if (lock && img) setH(Math.round((v * img.height) / img.width)); };
  const onH = (v: number) => { setH(v); if (lock && img) setW(Math.round((v * img.width) / img.height)); };
  const run = async () => {
    if (!img || !file) return;
    if (!(w > 0 && h > 0) || w * h > 4e7) return setMsg("Enter valid dimensions (up to about 40 megapixels).");
    setMsg("");
    const type = file.type === "image/png" || file.type === "image/webp" ? file.type : "image/jpeg";
    const c = makeCanvas(w, h), x = c.getContext("2d")!;
    x.imageSmoothingQuality = "high"; x.drawImage(img, 0, 0, w, h);
    setOut(await toBlob(c, type, 0.92));
  };
  return (
    <div className="space-y-4">
      <Dropzone onFiles={set} />
      <Err msg={error || msg} />
      {img && (
        <>
          <div className="grid items-end gap-4 sm:grid-cols-3">
            <Field label="Width (px)"><input className="input" type="number" min={1} value={w || ""} onChange={(e) => onW(+e.target.value)} /></Field>
            <Field label="Height (px)"><input className="input" type="number" min={1} value={h || ""} onChange={(e) => onH(+e.target.value)} /></Field>
            <label className="flex items-center gap-2 pb-2 text-sm text-slate-600"><input type="checkbox" checked={lock} onChange={(e) => setLock(e.target.checked)} /> Lock aspect ratio</label>
          </div>
          <p className="text-sm text-slate-500">Original: {img.width}×{img.height}px</p>
          <button className="btn" onClick={run}>Resize image</button>
        </>
      )}
      <Result blob={out} name={file && out ? `${baseName(file)}-${w}x${h}.${EXT[out.type] || "jpg"}` : ""} info={out ? `${w}×${h}px · ${kb(out.size)}` : undefined} />
    </div>
  );
}
