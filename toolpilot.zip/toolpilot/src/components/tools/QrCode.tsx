"use client";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Err, Field, Result } from "../ui";

export default function QrCodeTool() {
  const [text, setText] = useState("https://example.com");
  const [size, setSize] = useState(512), [color, setColor] = useState("#000000"), [ec, setEc] = useState<"L" | "M" | "Q" | "H">("M");
  const [out, setOut] = useState<Blob | null>(null), [msg, setMsg] = useState("");
  useEffect(() => {
    if (!text) { setOut(null); return; }
    let live = true;
    const c = document.createElement("canvas");
    QRCode.toCanvas(c, text, { width: size, margin: 2, errorCorrectionLevel: ec, color: { dark: color, light: "#ffffff" } })
      .then(() => c.toBlob((b) => { if (live && b) { setOut(b); setMsg(""); } }, "image/png"))
      .catch(() => live && setMsg("That text is too long for a QR code."));
    return () => { live = false; };
  }, [text, size, color, ec]);
  return (
    <div className="space-y-4">
      <Field label="Text or URL"><textarea className="input" rows={3} value={text} onChange={(e) => setText(e.target.value)} /></Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label={`Size: ${size}px`}><input type="range" min={200} max={1200} step={50} value={size} onChange={(e) => setSize(+e.target.value)} className="w-full" /></Field>
        <Field label="Color"><input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-10 w-full rounded-xl border border-slate-300" /></Field>
        <Field label="Error correction"><select className="input" value={ec} onChange={(e) => setEc(e.target.value as "L" | "M" | "Q" | "H")}><option value="L">Low</option><option value="M">Medium</option><option value="Q">Quartile</option><option value="H">High</option></select></Field>
      </div>
      <Err msg={msg} />
      <Result blob={out} name="qr-code.png" info={out ? `${size}×${size}px PNG` : undefined} />
    </div>
  );
}
