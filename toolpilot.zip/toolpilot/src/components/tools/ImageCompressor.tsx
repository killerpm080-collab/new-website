"use client";
import { useEffect, useState } from "react";
import { Dropzone, Err, Field, Result, useImageSource, makeCanvas, toBlob, kb, baseName, EXT } from "../ui";

export default function ImageCompressor() {
  const { file, img, set, error } = useImageSource();
  const [q, setQ] = useState(75);
  const [type, setType] = useState("image/jpeg");
  const [out, setOut] = useState<Blob | null>(null);
  useEffect(() => {
    if (!img) return;
    let live = true;
    (async () => {
      const c = makeCanvas(img.width, img.height), x = c.getContext("2d")!;
      x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0);
      const b = await toBlob(c, type, q / 100);
      if (live) setOut(b);
    })();
    return () => { live = false; };
  }, [img, q, type]);
  return (
    <div className="space-y-4">
      <Dropzone onFiles={set} hint="JPG, PNG or WebP" />
      <Err msg={error} />
      {img && (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={`Quality: ${q}%`}><input type="range" min={10} max={100} value={q} onChange={(e) => setQ(+e.target.value)} className="w-full" /></Field>
          <Field label="Output format"><select className="input" value={type} onChange={(e) => setType(e.target.value)}><option value="image/jpeg">JPG</option><option value="image/webp">WebP</option></select></Field>
        </div>
      )}
      <Result blob={out} name={file ? `${baseName(file)}-compressed.${EXT[type]}` : ""} info={file && out ? `${kb(file.size)} → ${kb(out.size)} (${Math.round((1 - out.size / file.size) * 100)}% smaller)` : undefined} />
    </div>
  );
}
