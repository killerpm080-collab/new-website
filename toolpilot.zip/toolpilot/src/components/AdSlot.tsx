"use client";
import { useEffect } from "react";
import { SITE } from "@/lib/site";
declare global { interface Window { adsbygoogle?: unknown[] } }

/** AdSense-ready slot. Renders nothing in production until NEXT_PUBLIC_ADSENSE_CLIENT is set.
 *  Space is reserved (min-height) so ads never cause layout shift. */
export default function AdSlot({ slot, className = "" }: { slot?: string; className?: string }) {
  useEffect(() => {
    if (!SITE.adsense) return;
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch {}
  }, []);
  if (!SITE.adsense) {
    return process.env.NODE_ENV === "production" ? null : (
      <div className={`flex min-h-[100px] items-center justify-center rounded-xl border border-dashed border-slate-300 text-xs text-slate-400 ${className}`}>Ad slot (dev preview)</div>
    );
  }
  return (
    <div className={`min-h-[100px] text-center ${className}`} aria-label="Advertisement">
      <p className="mb-1 text-[10px] uppercase tracking-widest text-slate-400">Advertisement</p>
      <ins className="adsbygoogle" style={{ display: "block" }} data-ad-client={SITE.adsense} data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />
    </div>
  );
}
