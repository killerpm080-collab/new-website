"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { CATEGORIES, TOOLS } from "@/lib/tools";

export default function ToolGrid() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("All");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return TOOLS.filter((t) => (cat === "All" || t.category === cat) && (!s || (t.name + t.short).toLowerCase().includes(s)));
  }, [q, cat]);
  return (
    <div>
      <input className="input mb-4 max-w-md" type="search" placeholder="Search tools… (e.g. compress, QR, PDF)" aria-label="Search tools" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mb-6 flex flex-wrap gap-2">
        {["All", ...CATEGORIES].map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`rounded-full border px-3 py-1 text-sm ${cat === c ? "border-brand-600 bg-brand-600 text-white" : "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"}`}>{c}</button>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((t) => (
          <Link key={t.slug} href={`/tools/${t.slug}`} className="group card flex gap-3 !p-4 transition hover:-translate-y-0.5 hover:border-brand-500 hover:shadow-md">
            <span className="text-3xl">{t.icon}</span>
            <span><b className="block text-slate-900 group-hover:text-brand-600">{t.name}</b><span className="text-sm text-slate-500">{t.short}</span></span>
          </Link>
        ))}
        {!list.length && <p className="text-slate-500">No tools found. Try another search.</p>}
      </div>
    </div>
  );
}
