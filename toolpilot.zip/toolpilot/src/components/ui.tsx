"use client";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";

export const kb = (b: number) => (b > 1048576 ? `${(b / 1048576).toFixed(2)} MB` : `${(b / 1024).toFixed(1)} KB`);
export const baseName = (f: File) => f.name.replace(/\.[^.]+$/, "");
export const EXT: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
export function saveBlob(b: Blob, name: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(b); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
export const loadImage = (f: File) =>
  new Promise<HTMLImageElement>((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error("Could not read image")); i.src = URL.createObjectURL(f); });
export const makeCanvas = (w: number, h: number) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; };
export const toBlob = (c: HTMLCanvasElement, type: string, q?: number) =>
  new Promise<Blob>((ok, no) => c.toBlob((b) => (b ? ok(b) : no(new Error("Encoding failed"))), type, q));
export const copy = (s: string) => navigator.clipboard?.writeText(s);

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="label">{label}</span>{children}</label>;
}
export function Dropzone({ onFiles, accept = "image/*", multiple = false, hint }: { onFiles: (f: File[]) => void; accept?: string; multiple?: boolean; hint?: string }) {
  const [over, setOver] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div
      onClick={() => ref.current?.click()}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); onFiles([...e.dataTransfer.files]); }}
      className={`cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center text-slate-500 transition ${over ? "border-brand-500 bg-brand-50" : "border-slate-300 hover:border-brand-500"}`}
    >
      <input ref={ref} type="file" hidden accept={accept} multiple={multiple} onChange={(e) => { onFiles([...(e.target.files || [])]); e.target.value = ""; }} />
      <p><b className="text-brand-600">Click to choose</b> or drop {multiple ? "files" : "a file"} here</p>
      <p className="mt-1 text-xs">{hint || "Processed on your device. Nothing is uploaded."}</p>
    </div>
  );
}
export function useImageSource() {
  const [file, setFile] = useState<File | null>(null);
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [error, setError] = useState("");
  const set = async (fs: File[]) => {
    const f = fs[0]; if (!f) return;
    if (!f.type.startsWith("image/")) return setError("Please choose an image file.");
    try { setError(""); setFile(f); setImg(await loadImage(f)); } catch { setError("This image could not be opened."); }
  };
  return { file, img, set, error };
}
export function Result({ blob, name, info }: { blob: Blob | null; name: string; info?: string }) {
  const url = useMemo(() => (blob ? URL.createObjectURL(blob) : ""), [blob]);
  useEffect(() => () => { if (url) URL.revokeObjectURL(url); }, [url]);
  if (!blob) return null;
  return (
    <div className="mt-2 space-y-3 rounded-2xl bg-slate-50 p-4">
      {blob.type.startsWith("image/") && <img src={url} alt="Result preview" className="max-h-96 max-w-full rounded-xl bg-[repeating-conic-gradient(#e2e8f0_0_25%,#fff_0_50%)] bg-[length:16px_16px]" />}
      {info && <p className="text-sm text-slate-600">{info}</p>}
      <button className="btn" onClick={() => saveBlob(blob, name)}>⬇ Download {name}</button>
    </div>
  );
}
export const Err = ({ msg }: { msg: string }) => (msg ? <p role="alert" className="text-sm text-red-600">{msg}</p> : null);
export const Stat = ({ k, v }: { k: string; v: ReactNode }) => (
  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3"><p className="text-xs text-slate-500">{k}</p><p className="text-xl font-bold text-slate-900">{v}</p></div>
);
