/** Change SITE.name here (and in .env) to rename the whole website. */
export const SITE = {
  name: "ToolPilot",
  tagline: "Free Online Tools That Run in Your Browser",
  description:
    "Free online tools for images, PDFs, text, calculators and developers. Compress images, merge PDFs, make QR codes and more. 100% private: everything runs in your browser.",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "https://toolpilot.example").replace(/\/$/, ""),
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "hello@toolpilot.example",
  adsense: process.env.NEXT_PUBLIC_ADSENSE_CLIENT || "",
};
