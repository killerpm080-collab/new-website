import type { Metadata } from "next";
import FaqList, { faqJsonLd } from "@/components/FaqList";
import JsonLd from "@/components/JsonLd";
import { SITE_FAQ } from "@/lib/tools";
export const metadata: Metadata = { title: "FAQ", description: "Answers to common questions about our free online tools, privacy and how they work.", alternates: { canonical: "/faq" } };
export default function Faq() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <JsonLd data={faqJsonLd(SITE_FAQ)} />
      <h1 className="mb-6 text-3xl font-extrabold text-slate-900">Frequently asked questions</h1>
      <FaqList items={SITE_FAQ} />
    </div>
  );
}
