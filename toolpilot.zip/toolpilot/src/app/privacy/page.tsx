import type { Metadata } from "next";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Privacy Policy", description: `How ${SITE.name} handles your data. Our tools run in your browser and your files are never uploaded.`, alternates: { canonical: "/privacy" } };
export default function Privacy() {
  return (
    <div className="prose-page mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold text-slate-900">Privacy Policy</h1>
      <p>Last updated: October 2026</p>
      <h2>Your files and text stay on your device</h2>
      <p>All tools on {SITE.name} process data locally in your web browser. Images, PDFs and text you use with our tools are not uploaded to our servers and we cannot see them.</p>
      <h2>Information we collect</h2>
      <p>We do not require accounts and we do not run a database of user data. Our hosting provider may keep standard server logs (such as IP address, browser type and pages requested) for security and operations.</p>
      <h2>Cookies and advertising</h2>
      <p>We may display ads served by Google AdSense and other partners. These third parties may use cookies or similar technologies to show ads based on your visits to this and other websites. You can manage personalized advertising at <a href="https://adssettings.google.com" rel="noopener noreferrer" target="_blank">adssettings.google.com</a> and learn more about how Google uses data at <a href="https://policies.google.com/technologies/partner-sites" rel="noopener noreferrer" target="_blank">policies.google.com/technologies/partner-sites</a>.</p>
      <h2>Analytics</h2>
      <p>If we add analytics, we will use it only to understand which tools are popular, and we will update this page.</p>
      <h2>Children</h2>
      <p>This site is a general audience website and is not directed at children under 13.</p>
      <h2>Changes</h2>
      <p>We may update this policy and will change the date above when we do.</p>
      <h2>Contact</h2>
      <p>Questions? Email <a href={`mailto:${SITE.email}`}>{SITE.email}</a>.</p>
    </div>
  );
}
