import type { Metadata } from "next";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Terms of Service", description: `Terms of use for ${SITE.name}.`, alternates: { canonical: "/terms" } };
export default function Terms() {
  return (
    <div className="prose-page mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold text-slate-900">Terms of Service</h1>
      <p>Last updated: October 2026</p>
      <h2>Using the site</h2>
      <p>By using {SITE.name} you agree to these terms. You may use the tools for personal and commercial purposes, provided you follow the law and do not misuse the service.</p>
      <h2>Your content</h2>
      <p>You keep all rights to your files and text. Because processing happens in your browser, we do not receive or store your content. You are responsible for having the right to use any files you process.</p>
      <h2>No warranty</h2>
      <p>The tools are provided &quot;as is&quot; without warranties of any kind. Results such as calculations, conversions and health or financial estimates are for general information only and are not professional advice. Always double-check important results.</p>
      <h2>Limitation of liability</h2>
      <p>To the maximum extent permitted by law, {SITE.name} is not liable for any loss or damage arising from your use of the tools.</p>
      <h2>Changes</h2>
      <p>We may change the tools or these terms at any time. Continued use means you accept the updated terms.</p>
      <h2>Contact</h2>
      <p>Questions? Email <a href={`mailto:${SITE.email}`}>{SITE.email}</a>.</p>
    </div>
  );
}
