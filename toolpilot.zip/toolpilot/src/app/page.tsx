import type { Metadata } from "next";
import Link from "next/link";
import Hero3D from "@/components/Hero3D";
import ToolGrid from "@/components/ToolGrid";
import AdSlot from "@/components/AdSlot";
import FaqList, { faqJsonLd } from "@/components/FaqList";
import JsonLd from "@/components/JsonLd";
import { SITE } from "@/lib/site";
import { SITE_FAQ, TOOLS } from "@/lib/tools";

export const metadata: Metadata = { alternates: { canonical: "/" } };

const features = [
  ["🔒", "Private by design", "Your files and text are processed in your browser. Nothing is uploaded or stored."],
  ["⚡", "Fast on any device", "No sign-up, no waiting for servers. Tools load instantly, even on a phone."],
  ["🆓", "Free, no limits", "No watermarks, no daily caps and no paid tiers for basic use."],
];
export default function Home() {
  return (
    <>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "WebSite", name: SITE.name, url: SITE.url, description: SITE.description }} />
      <JsonLd data={faqJsonLd(SITE_FAQ)} />
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_75%_40%,rgba(139,92,246,.35),transparent),radial-gradient(40%_40%_at_15%_85%,rgba(236,72,153,.25),transparent)]" />
        <Hero3D />
        <div className="relative mx-auto max-w-6xl px-4 py-20 sm:py-28 lg:py-36">
          <div className="max-w-xl">
            <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs text-slate-200">✨ {TOOLS.length} free tools · no sign-up</span>
            <h1 className="mt-4 text-4xl font-extrabold leading-tight tracking-tight sm:text-6xl">
              Free online tools that <span className="bg-gradient-to-r from-violet-400 to-pink-400 bg-clip-text text-transparent">just work.</span>
            </h1>
            <p className="mt-4 text-lg text-slate-300">Compress images, merge PDFs, make QR codes, count words, calculate loans and more. Everything runs in your browser, so your files stay on your device.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="#tools" className="btn">Browse all tools →</Link>
              <Link href="/tools/image-compressor" className="inline-flex items-center rounded-xl border border-white/25 px-5 py-2.5 text-sm font-semibold hover:bg-white/10">Compress an image</Link>
            </div>
          </div>
        </div>
      </section>
      <section id="tools" className="mx-auto max-w-6xl scroll-mt-16 px-4 py-14">
        <h2 className="text-3xl font-bold text-slate-900">All tools</h2>
        <p className="mb-6 mt-1 text-slate-500">Pick a tool and start. No account needed.</p>
        <ToolGrid />
      </section>
      <div className="mx-auto max-w-6xl px-4"><AdSlot slot="" /></div>
      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-14 sm:grid-cols-3">
        {features.map(([i, t, d]) => (
          <div key={t} className="card"><p className="text-3xl">{i}</p><h3 className="mt-2 text-lg font-bold text-slate-900">{t}</h3><p className="mt-1 text-slate-600">{d}</p></div>
        ))}
      </section>
      <section className="mx-auto max-w-3xl px-4 pb-6">
        <h2 className="mb-4 text-3xl font-bold text-slate-900">Frequently asked questions</h2>
        <FaqList items={SITE_FAQ} />
      </section>
    </>
  );
}
