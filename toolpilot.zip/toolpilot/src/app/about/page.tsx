import type { Metadata } from "next";
import { SITE } from "@/lib/site";
import { TOOLS } from "@/lib/tools";
export const metadata: Metadata = { title: "About", description: `About ${SITE.name}: free, private online tools that run entirely in your browser.`, alternates: { canonical: "/about" } };
export default function About() {
  return (
    <div className="prose-page mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold text-slate-900">About {SITE.name}</h1>
      <p>{SITE.name} is a collection of {TOOLS.length} free online tools that solve everyday problems: shrinking a photo, merging PDFs, counting words, working out a loan payment, making a QR code and more.</p>
      <h2>Why we built it</h2>
      <p>Most online tools make you upload your files to someone else&apos;s server, wait, and often sign up. We think simple jobs should be fast and private. So every tool here runs inside your own browser.</p>
      <h2>What makes it different</h2>
      <ul>
        <li><b>Private:</b> your images, PDFs and text never leave your device.</li>
        <li><b>Fast:</b> no uploads, no queues, and pages that load quickly on mobile.</li>
        <li><b>Free:</b> no sign-up, no watermarks. The site is supported by advertising.</li>
      </ul>
      <h2>Tell us what to build next</h2>
      <p>We add tools based on what people need. Send your idea through the contact page.</p>
    </div>
  );
}
