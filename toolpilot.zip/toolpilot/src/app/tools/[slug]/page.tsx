import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import AdSlot from "@/components/AdSlot";
import FaqList, { faqJsonLd } from "@/components/FaqList";
import JsonLd from "@/components/JsonLd";
import ToolRunner from "@/components/ToolRunner";
import { SITE } from "@/lib/site";
import { TOOLS, getTool, type Category } from "@/lib/tools";

export const dynamicParams = false;
export const generateStaticParams = () => TOOLS.map((t) => ({ slug: t.slug }));

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const tool = getTool((await params).slug);
  if (!tool) return {};
  const url = `/tools/${tool.slug}`;
  return {
    title: tool.title, description: tool.description, keywords: tool.keywords, alternates: { canonical: url },
    openGraph: { type: "website", title: `${tool.title} | ${SITE.name}`, description: tool.description, url },
    twitter: { card: "summary", title: tool.title, description: tool.description },
  };
}
const STEPS: Record<Category, string[]> = {
  "Image Tools": ["Upload or drop your image into the tool.", "Adjust the settings and watch the preview update.", "Download the finished image to your device."],
  "PDF Tools": ["Add your files to the tool.", "Arrange them in the order you want.", "Create the PDF and download it."],
  "Text Tools": ["Type or paste your text.", "Choose the options you need.", "Copy the result with one click."],
  Calculators: ["Enter your numbers.", "See the results instantly as you type.", "Change any value to compare scenarios."],
  "Developer & Design": ["Enter your input or upload a file.", "Choose your options.", "Copy or download the output."],
};
export default async function ToolPage({ params }: { params: Promise<{ slug: string }> }) {
  const tool = getTool((await params).slug);
  if (!tool) notFound();
  const url = `${SITE.url}/tools/${tool.slug}`;
  const related = TOOLS.filter((t) => t.category === tool.category && t.slug !== tool.slug).concat(TOOLS.filter((t) => t.category !== tool.category)).slice(0, 4);
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <JsonLd data={{ "@context": "https://schema.org", "@type": "WebApplication", name: tool.name, description: tool.description, url, applicationCategory: "UtilitiesApplication", operatingSystem: "Any", offers: { "@type": "Offer", price: "0", priceCurrency: "USD" } }} />
      <JsonLd data={faqJsonLd(tool.faq)} />
      <JsonLd data={{ "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Home", item: SITE.url }, { "@type": "ListItem", position: 2, name: tool.name, item: url }] }} />
      <nav aria-label="Breadcrumb" className="text-sm text-slate-500"><Link href="/" className="hover:text-brand-600">Home</Link> / <Link href="/#tools" className="hover:text-brand-600">{tool.category}</Link> / {tool.name}</nav>
      <h1 className="mt-3 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">{tool.icon} {tool.name}</h1>
      <p className="mt-2 text-lg text-slate-600">{tool.short} Free, private and runs entirely in your browser.</p>
      <AdSlot slot="" className="my-6" />
      <section className="card" aria-label={tool.name}><ToolRunner slug={tool.slug} /></section>
      <AdSlot slot="" className="my-6" />
      <section className="mt-10">
        <h2 className="text-2xl font-bold text-slate-900">How to use the {tool.name}</h2>
        <ol className="mt-3 list-decimal space-y-2 pl-6 text-slate-600">{STEPS[tool.category].map((s) => <li key={s}>{s}</li>)}</ol>
      </section>
      <section className="mt-10">
        <h2 className="mb-4 text-2xl font-bold text-slate-900">Frequently asked questions</h2>
        <FaqList items={tool.faq} />
      </section>
      <section className="mt-10">
        <h2 className="mb-4 text-2xl font-bold text-slate-900">More free tools</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {related.map((t) => (
            <Link key={t.slug} href={`/tools/${t.slug}`} className="card flex gap-3 !p-4 hover:border-brand-500"><span className="text-2xl">{t.icon}</span><span><b className="block text-slate-900">{t.name}</b><span className="text-sm text-slate-500">{t.short}</span></span></Link>
          ))}
        </div>
      </section>
    </div>
  );
}
