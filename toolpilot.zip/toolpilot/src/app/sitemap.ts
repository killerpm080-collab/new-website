import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";
import { TOOLS } from "@/lib/tools";
export const dynamic = "force-static";
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const pages = ["", "/faq", "/about", "/contact", "/privacy", "/terms"].map((p) => ({
    url: SITE.url + p, lastModified: now, changeFrequency: "monthly" as const, priority: p === "" ? 1 : 0.5,
  }));
  const tools = TOOLS.map((t) => ({ url: `${SITE.url}/tools/${t.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 }));
  return [...pages, ...tools];
}
