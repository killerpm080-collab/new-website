import Link from "next/link";
export default function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-6xl">🧭</p>
      <h1 className="mt-4 text-3xl font-extrabold text-slate-900">Page not found</h1>
      <p className="mt-2 text-slate-600">That page doesn&apos;t exist, but plenty of useful tools do.</p>
      <Link href="/#tools" className="btn mt-6">Browse tools</Link>
    </div>
  );
}
