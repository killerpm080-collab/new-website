"use client";
import { useState } from "react";
import { SITE } from "@/lib/site";
export default function ContactForm() {
  const [name, setName] = useState(""), [msg, setMsg] = useState("");
  const go = (e: React.FormEvent) => {
    e.preventDefault();
    window.location.href = `mailto:${SITE.email}?subject=${encodeURIComponent("Message from " + (name || "a visitor"))}&body=${encodeURIComponent(msg)}`;
  };
  return (
    <form onSubmit={go} className="card mt-6 space-y-4">
      <label className="block"><span className="label">Your name</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label>
      <label className="block"><span className="label">Message</span><textarea required className="input" rows={6} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Feedback, bug report or a tool you would like us to build…" /></label>
      <button className="btn" type="submit">Send by email</button>
      <p className="text-xs text-slate-500">This opens your email app with the message ready to send. We don&apos;t store anything on a server.</p>
    </form>
  );
}
