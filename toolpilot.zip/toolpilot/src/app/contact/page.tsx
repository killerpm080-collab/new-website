import type { Metadata } from "next";
import { SITE } from "@/lib/site";
import ContactForm from "./ContactForm";
export const metadata: Metadata = { title: "Contact", description: `Contact ${SITE.name} with feedback, bug reports or tool requests.`, alternates: { canonical: "/contact" } };
export default function Contact() {
  return (
    <div className="prose-page mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-3xl font-extrabold text-slate-900">Contact us</h1>
      <p>Found a bug, have feedback or want a new tool? Email us at <a className="font-semibold text-brand-600" href={`mailto:${SITE.email}`}>{SITE.email}</a> or use the form below.</p>
      <ContactForm />
    </div>
  );
}
