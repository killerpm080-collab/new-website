/** Static export: deploy the `out/` folder to any free static host (Cloudflare Pages, Netlify, Vercel, GitHub Pages). */
const nextConfig = { output: "export", reactStrictMode: true, poweredByHeader: false, images: { unoptimized: true }, trailingSlash: false };
export default nextConfig;
